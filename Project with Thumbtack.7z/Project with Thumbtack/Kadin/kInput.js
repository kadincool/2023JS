var inputs = {
  //movement
  up: false,
  down: false,
  left: false,
  right: false,
  action: false,
  //ui
  ui_up: false,
  ui_down: false,
  ui_left: false,
  ui_right: false,
  ui_accept: false,
  ui_back: false,
  ui_pause: false,
  //inventory
  inv_drop: false,
  inv_left: false,
  inv_right: false,
};

document.addEventListener("keydown", (pressed) => {
  if (pressed.key=="Insert") {
    alert("result: " + eval(prompt("Run code:")));
  }
  if (pressed.key.toLowerCase() == "w" || pressed.key == "ArrowUp") {
    inputs.up = true;
    inputs.ui_up = true;
  }
  if (pressed.key.toLowerCase() == "s" || pressed.key == "ArrowDown") {
    inputs.down = true;
    inputs.ui_down = true;
  }
  if (pressed.key.toLowerCase() == "a" || pressed.key == "ArrowLeft") {
    inputs.left = true;
    inputs.ui_left = true;
  }
  if (pressed.key.toLowerCase() == "d" || pressed.key == "ArrowRight") {
    inputs.right = true;
    inputs.ui_right = true;
  }
  if (pressed.key == " ") {
    inputs.action = true;
    inputs.ui_accept = true;
  }
  if (pressed.key == "Escape") {
    inputs.ui_back = true;
  }
  if (pressed.key == "Tab") {
    inputs.ui_pause = true;
  }
  if (pressed.key.toLowerCase() == "q") {
    inputs.inv_left = true;
  }
  if (pressed.key.toLowerCase() == "e") {
    inputs.inv_right = true;
  }
  if (pressed.key.toLowerCase() == "f") {
    inputs.inv_drop = true;
  }
  //alert(pressed.key)
});

document.addEventListener("keyup", (released) => {
  if (released.key.toLowerCase() == "w" || released.key == "ArrowUp") {
    inputs.up = false;
  }
  if (released.key.toLowerCase() == "s" || released.key == "ArrowDown") {
    inputs.down = false;
  }
  if (released.key.toLowerCase() == "a" || released.key == "ArrowLeft") {
    inputs.left = false;
  }
  if (released.key.toLowerCase() == "d" || released.key == "ArrowRight") {
    inputs.right = false;
  }
  if (released.key == " ") {
    inputs.action = false;
  }
});

function ui_reset() {
  inputs.ui_up = false;
  inputs.ui_down = false;
  inputs.ui_left = false;
  inputs.ui_right = false;
  inputs.ui_accept = false;
  inputs.ui_back = false;
  inputs.ui_pause = false;
  inputs.inv_drop = false;
  inputs.inv_left = false;
  inputs.inv_right = false;
}