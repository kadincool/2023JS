var roomLayout;
var entityLayout;
var dunDat;
var tileDat;
var entityDat;
var itemDat;
var lastTime;
var deltaTime = 0;
var settings;
var player;
const honeyHelpILeftTheOvenOnAndItsOnFireAndIsSpreadingAroundTheHouseIHaveNoCellServiceAndThePotatoesAreGrowingLegsPleaseCall911 = null; //#notAWasteOfAVariableName

function initBackendGame() {
  roomLayout = [];//list of rooms. the dungeon will be 5 rooms by 5 rooms. each room will be 10 x 8 tiles (width x height).
  entityLayout = [];
  dunDat = {
    dunWidth:5,
    dunHeight:5,
    roomWidth:15,
    roomHeight:11,
    currRoom:0,
    seed:10
  };
  tileDat = [
    {
      name: "floor",
      walkable: true,
      spriteX: 0,
      spriteY: 0,
      spriteW: 16,
      spriteH: 16,
      color: "#048",
    },
    {
      name: "voidWall",
      walkable: false,
      spriteX: 16,
      spriteY: 0,
      spriteW: 16,
      spriteH: 16,
      color: "#000",
    },
    {
      name: "brickWall",
      walkable: false,
      spriteX: 32,
      spriteY: 0,
      spriteW: 16,
      spriteH: 16,
      color: "#47d",
    },
    {
      name: "keyDoor",
      walkable: false,
      spriteX: 48,
      spriteY: 0,
      spriteW: 16,
      spriteH: 16,
      color: "#69d",
      onWalk: "keyDoorWalk",
    },
  ];
  entityDat = [
    {
      name: "player",
      color: "#0ff",
      onTick: "playerTick",
      onHit: "playerHit",
      inventory: [],
    },
    {
      name: "goblin",
      color: "#1d3",
      goldDrop: 3,
      baseHealth: 2,
      walkable: false,
      onHit: "goblinHit",
      onTick: "goblinTick",
    },
    {
      name: "screenSaver",
      color: "#6af",
      goldDrop: 4,
      baseHealth: 3,
      xDir: 1,
      yDir: 1,
      onTick: "saverTick",
      onHit: "saverHit",
    },
    {
      name: "key",
      color: "#dc1",
      onHit: "keyHit",
    },
    {
      name: "O2 tank",
      color: "#fed",
    }
  ];
  itemDat = [
    {
      name: "key",
      color: "#dc1",
    }
  ];
  lastTime = Date.now();
  settings = {
    animSpeed: 5,
  };
  player = {
    x: ~~(dunDat.roomWidth/2),
    y: ~~(dunDat.roomHeight/2), //tile x and y, not pixel.
    xAnimSpeed: 1,
    yAnimSpeed: 1,
    addX: 0,
    addY: 0,//offset in pixels
    toAddX: 0,
    toAddY: 0,
    inventory: [0],
    inventorySize: 5,
    gold: 0,
    health: 3,
    maxHealth: 3,
    energy: 100,
    maxEnergy: 100,
  };
  generate(dunDat);
  genRoom(0,0);
  addEntity("goblin",3,3);
  addEntity("screenSaver",5,3);
  /*for (let i=1; i<14; i++) {
    addEntity("player", i, 2);
  }//*/
  addEntity("player", 7, 3);
}

function logMap(map) {
  let output = [];
  for (let i=0; i<map.length; i++) {
    if (i%dunDat.dunWidth == 0) {
      output[i/dunDat.dunWidth] = [];
    }
    output[Math.floor(i/dunDat.dunWidth)][i%dunDat.dunWidth] = map[i].room;
  }
  console.table(output);
}

function generate(dat) {
  if (dat) {
    dunDat = dat; //for (let i=0; i<24; i++) {console.log(hash(dunDat.seed + "," + i)%(dunDat.dunWidth*dunDat.dunHeight))}
  } else {
    dunDat = {dunWidth:5, dunHeight:5, roomWidth:15, roomHeight:11};
  }
  dunDat.seed = Math.floor(Math.random()*1024);
  dunDat.currRoom = 0;
  roomLayout = []
  let map = []
  for (let i=0; i<dunDat.dunWidth*dunDat.dunHeight; i++) {
    map.push({room: 0, up: 0, down: 0, left: 0, right: 0});
  }
  let startIndex = hash(dunDat.seed + ",start")%map.length;
  map[startIndex].room = 1; //start room
  //make end tile not be in same tile as start
  let endIndex = hash(dunDat.seed + ",end")%(map.length-1);
  if (endIndex>=startIndex) endIndex+=1;
  map[endIndex].room = 2; //end room
  logMap(map);
}

initBackendGame();

Number.prototype.clamp = function (min,max) {
  return Math.min(Math.max(this, min), max)
}

function updateBackend() {
  deltaTime = Date.now() - lastTime;
  lastTime+=deltaTime;
  deltaTime/=1000;

  if (!game.paused) {
    for (let i=0; i<entityLayout.length; i++) {
      if (entityLayout[i].onTick) {
        behaviorFuncs[entityLayout[i].onTick](i);
      }
    }
  }

  draw();
  requestAnimationFrame(updateBackend);
}

function genRoom(roomX,roomY) {
  let size = dunDat.roomWidth*dunDat.roomHeight;
  let room = [];
  for (let i = 0; i<size; i++) {
    room[i]=genTile(i%dunDat.roomWidth,~~(i/dunDat.roomWidth));
  }
  roomLayout[roomX+roomY*dunDat.dunWidth]=room;
}

function genTile(tileX,tileY) {
  if (tileX==0||tileX==dunDat.roomWidth-1) {
    if (tileY==Math.floor(dunDat.roomHeight/2)) {
      return 3;
    }
    return 2;
  }
  if (tileY==0||tileY==dunDat.roomHeight-1) {
    return 2;
  }
  return 0;
}

function getTile(x,y) {
  let room = roomLayout[~~(x/dunDat.roomWidth)+~~(y/dunDat.roomHeight)*dunDat.dunWidth];
  if (room==0||room==undefined) {
    return 1;//void cell
  }
  return room[~~(x%dunDat.roomWidth)+~~(y%dunDat.roomHeight)*dunDat.roomWidth];
}

function setTile(x,y,set) {
  let room = roomLayout[~~(x/dunDat.roomWidth)+~~(y/dunDat.roomHeight)*dunDat.dunWidth];
  if (room==0||room==undefined) {
    return
  }
  room[~~(x%dunDat.roomWidth)+~~(y%dunDat.roomHeight)*dunDat.roomWidth]=set;
}

function attemptOperationOnTile(x,y,hitEntIndex) {
  let tileIQ = tileDat[getTile(x,y)]; //tile in question
  if (tileIQ.onWalk != undefined) {
    behaviorFuncs[tileIQ.onWalk](x,y,hitEntIndex);
  }
}

function addEntity(type,x,y,full=true) {
  let entityAdd = structuredClone(entityDat.find((curr) => curr.name == type));
  if (!entityAdd) {console.log(type + " doesn't exist"); return;}
  entityAdd.x = x;
  entityAdd.y = y;
  if (full) {
    entityAdd.addX = 0;
    entityAdd.addY = 0;
    entityAdd.xAnimSpeed = 1;
    entityAdd.yAnimSpeed = 1;
  }
  entityLayout.push(entityAdd);
}

function hash(value) {
  value = value.toString() + "keep it the same(this is an option not a name)";
  let hash = 0;
  for (let i=0; i<value.length; i++) {
    let charCode = value.charCodeAt(i);
    hash = ((hash << 5) - hash) + charCode
  }
  return Math.abs(hash);
}