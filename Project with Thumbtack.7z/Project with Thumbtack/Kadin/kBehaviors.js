behaviorFuncs = {
  keyDoorWalk: function(x,y,hitEntIndex) {
    let hitEnt = entityLayout[hitEntIndex];
    if (!hitEnt.inventory) return;
    if (hitEnt.inventory.includes(0)) {
      hitEnt.inventory.splice(hitEnt.inventory.indexOf(0)); 
      setTile(x,y,0);
    }
  },
  saverTick: function(index) {
    let entity = entityLayout[index];
    if (entity.addX==0 && !isWalkable(entity.x+entity.xDir, entity.y, index)) {
      entity.xDir *= -1;
    }
    if (entity.addY==0 && !isWalkable(entity.x, entity.y+entity.yDir, index)) {
      entity.yDir *= -1;
    }
    if (entity.addX==0 && entity.addY==0 && !isWalkable(entity.x+entity.xDir, entity.y+entity.yDir, index)) {
      entity.xDir *= -1;
      entity.yDir *= -1;
    }

    if (entity.addX == 0) {
      entity.toAddX = entity.xDir;
    }
    if (entity.addY == 0) {
      entity.toAddY = entity.yDir;
    }
    move(index);
    smooth(entity);
  },
  saverHit: function(index,hitEntIndex) {
    entityLayout.splice(index,1);
  },
  keyHit: function(index,hitEntIndex) {
    if (inventory.length<inventorySize) {
      inventory.push(0);
      entityLayout.splice(index,1);
      return;
    }
  },
  playerTick: function(index) {
    let player = entityLayout[index];
    smooth(player);
    if (inputs.down && player.addY==0) {
      if (inputs.action) player.yAnimSpeed = 3; else player.yAnimSpeed = 1;
      player.toAddY+=player.yAnimSpeed;
    }
    if (inputs.up && player.addY==0) {
      if (inputs.action) player.yAnimSpeed = 3; else player.yAnimSpeed = 1;
      player.toAddY-=player.yAnimSpeed;
    }
    if (inputs.left && player.addX==0) {
      if (inputs.action) player.xAnimSpeed = 3; else player.xAnimSpeed = 1;
      player.toAddX-=player.xAnimSpeed;
    }
    if (inputs.right && player.addX==0) {
      if (inputs.action) player.xAnimSpeed = 3; else player.xAnimSpeed = 1;
      player.toAddX+=player.xAnimSpeed;
    }
    move(index);
    
  },
  playerHit: function(index, hitEntIndex) {
    entityLayout.splice(index, 1);
  },
  goblinHit: function(index, hitEntIndex) {
    //alert("hit");
    knockback(index, hitEntIndex);
  },
  goblinTick: function(index) {
    //let goblin = entityLayout[index];
    smooth(entityLayout[index]);
  }
}

function move(index, interact=true) {
  let entity = entityLayout[index];
  let xDir = Math.sign(entity.toAddX);
  for (let i=0; i<Math.abs(entity.toAddX); i++) {
    if (isWalkable(entity.x+xDir,entity.y,index,interact)) {
      entity.x += xDir;
      entity.addX -= xDir;
    }
  }
  entity.toAddX = 0;
  let yDir = Math.sign(entity.toAddY);
  for (let i=0; i<Math.abs(entity.toAddY); i++) {
    if (isWalkable(entity.x, entity.y+yDir, index, interact)) {
      entity.y += yDir;
      entity.addY -= yDir;
    }
  }
  entity.toAddY = 0;
}

function smooth(entity) {
  if (Math.abs(entity.addX)<deltaTime*settings.animSpeed*entity.xAnimSpeed) {
    entity.addX=0;
  } else {
    entity.addX+=deltaTime*-Math.sign(entity.addX)*settings.animSpeed*entity.xAnimSpeed;
  }
  if (Math.abs(entity.addY)<deltaTime*settings.animSpeed*entity.yAnimSpeed) {
    entity.addY=0;
  } else {
    entity.addY+=deltaTime*-Math.sign(entity.addY)*settings.animSpeed*entity.yAnimSpeed;
  }
}

function entityAtTile(x,y) {
  for (let i = 0; i<entityLayout.length; i++) {
    if (entityLayout[i].x == x && entityLayout[i].y == y) {
      return i;
    }
  }
  return;
}

function isWalkable(x,y,entity,interact=true) {
  let hitEnt = entityAtTile(x,y);
  if (hitEnt!=undefined && !hitEnt.walkable) {
    if (entityLayout[hitEnt].onHit && interact) {
      behaviorFuncs[entityLayout[hitEnt].onHit](hitEnt, entity); //!?
    }
    return false;
  }
  if (interact && tileDat[getTile(x,y)].onHit) {
    behaviorFuncs[tileDat[getTile(x,y)]](x,y,hitEnt);
  }
  if (!tileDat[getTile(x,y)].walkable) {
    return false;
  }
  return true;
}

function knockback(index, hitEntIndex) { //hitEnt is the one who attacked
  let entity = entityLayout[index];
  let hitEnt = entityLayout[hitEntIndex];

  if (entity.x > hitEnt.x) {
    entity.toAddX = 1;
    move(index);
  } else if (entity.x < hitEnt.x) {
    entity.toAddX = -1;
    move(index);
  }
  if (entity.y > hitEnt.y) {
    entity.toAddY = 1;
    move(index);
  } else if (entity.y < hitEnt.y) {
    entity.toAddY = -1;
    move(index);
  }
}