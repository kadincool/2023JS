scale = Math.min(window.innerHeight/(dunDat.roomHeight+2), window.innerWidth/(dunDat.roomWidth+2));

function draw() {
  ctx.fillRect(0,0,canvas.width,canvas.height);
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  ctx.translate(~~(canvas.width/2-dunDat.roomWidth*scale/2),~~(canvas.height/2-dunDat.roomHeight*scale/2));
  drawRoom(dunDat.currRoom,0,0,scale);
  drawEntities(0,0,scale);
}

function drawEntities(dx, dy, scale) {
  for (var i=0; i<entityLayout.length; i++) {
    ctx.fillStyle = entityLayout[i].color; //edited
    drawSquare((entityLayout[i].x+entityLayout[i].addX)*scale+dx,(entityLayout[i].y+entityLayout[i].addY)*scale+dy,scale,scale);
  }
}

function drawRoom(roomNum,x,y,scale) {
  for (let i=0; i<roomLayout[roomNum].length; i++) {
    ctx.fillStyle = tileDat[roomLayout[roomNum][i]].color;
    drawSquare(i%dunDat.roomWidth*scale+x,Math.floor(i/dunDat.roomWidth)*scale+y,scale,scale);
  }
}

function drawSquare(x, y, width, height, addX=0, addY=0) {
  let x2 = Math.round(x+width);
  let y2 = Math.round(y+height);
  x = Math.round(x);
  y = Math.round(y);
  ctx.fillRect(x+addX,y+addY,x2-x,y2-y);
}