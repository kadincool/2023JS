var canvas = document.getElementById("canvas")
var ctx = canvas.getContext("2d")

var game = {}
game.paused=true
game.keys=[]
game.cursor={x: 0, y: 0}
game.inMenu=true//lock controls

colors = ["maroon", "red", "orange", "yellow", "lime", "green", "blue", "cyan", "magenta", "purple", "black"]
items = [...colors]
itemIndex = 1

animateable = false
animationTime = 0.08

document.onwheel = function(e) {
  scrollInventory(-e.deltaY)
}

function scrollInventory(a) {
  if (animateable) {
    if (a>1) {
      itemIndex++
      document.getElementById('center-item').style.animation="a-scroll1 "+animationTime+"s linear";
      document.getElementById('left-item').style.animation="b-scroll1 "+animationTime+"s linear";//farther
      document.getElementById('right-item').style.animation="shrink "+animationTime+"s linear";
      animateable = false
    } else if (a<-1) {
      itemIndex--
      document.getElementById('center-item').style.animation="a-scroll2 "+animationTime+"s linear";
      document.getElementById('right-item').style.animation="b-scroll2 "+animationTime+"s linear";
      document.getElementById('left-item').style.animation="shrink "+animationTime+"s linear";
      animateable = false
    }
  }
}

document.getElementById('center-item').onanimationend = function() {
  document.getElementById('center-item').style["background-color"] = items[loop(itemIndex,items.length)]
  document.getElementById('left-item').style["background-color"] = items[loop(itemIndex+1,items.length)]
  document.getElementById('right-item').style["background-color"] = items[loop(itemIndex-1,items.length)]
  if (document.getElementById('center-item').style["animation-name"][0]!="a") {
    animateable = true;
  }
  document.getElementById('center-item').style.animation="idle 0s linear"
}

document.getElementById('left-item').onanimationend = function() {
  document.getElementById('left-item').style.animation="idle 0s linear"
}

document.getElementById('right-item').onanimationend = function() {
  document.getElementById('right-item').style.animation="idle 0s linear"
}

function loop(v,m) {
return ((v%m)+m)%m
}

function toCreditsPage() {
  document.getElementById("main-menu").style.display = "none"
  document.getElementById("credits-page").style.display = "block"
}

function toMainMenu() {
  closePauseMenu()
  game.paused=true
  document.getElementById("main-menu").style.display = "block"
  document.getElementById("credits-page").style.display = "none"
  document.getElementById("game-window").style.display = "none"
}

function openPauseMenu() {
  game.paused=true
  document.getElementById("pause-menu").style.display = "block"
  document.getElementById("hud").style.filter = "blur(2px)"
  document.getElementById("canvas").style.filter = "blur(4px)"
}

function closePauseMenu() {
  game.paused=false
  document.getElementById("hud").style.filter = "blur(0px)"
  document.getElementById("canvas").style.filter = "blur(0px)"
  //alert(game.paused)
  startGame()
  document.getElementById("pause-menu").style.display = "none"
}

function startGame() {
  game.paused = false
  updateBackend()
  document.getElementById("pause-menu").style.display = "none"
  document.getElementById("main-menu").style.display = "none"
  document.getElementById("game-window").style.display = "block"
}

function newGame() {
  initBackendGame()
  startGame()
}

document.onmousemove = function (e) {
  game.cursor.x = e.pageX
  game.cursor.y = e.pageY
}

document.onkeydown = function (e) {
  if(e.key=="q") scrollInventory(2)
  if(e.key=="e") scrollInventory(-2)
  game.keys[e.key] = true
}

document.onkeyup = function (e) {
  game.keys[e.key] = false
  if (e.key=="Escape") {
    if (game.paused) {
      closePauseMenu()
    } else {
      openPauseMenu()
    }
  }
}